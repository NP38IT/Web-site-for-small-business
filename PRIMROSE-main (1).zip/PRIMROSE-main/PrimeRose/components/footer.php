<footer class="footer">

   <section class="grid">

      <div class="box">
         <img src="images/oip.jpg" alt="">
         <h3>our email</h3>
         <a href="mailto:primerosecrafts@gmail.com">primerosecrafts@gmail.com</a>
      </div>

      <div class="box">
         <img src="images/clock.jpg" alt="">
         <h3>You can contacts us</h3>
         <p>24 hours</p>
      </div>

      <div class="box">
         <img src="images/number.jpg" alt="">
         <h3>Our Number</h3>
         <a href="tel:+94702930410">0702930410</a>
      </div>

   </section>


</footer>

<div class="loader">
   <img src="images/Loader3.gif" alt="">
</div>